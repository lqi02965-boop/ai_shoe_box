/*------------------------------------------------------
 * K230 Integration Test - Shoe Wash Project
 * USART3 (PB10/PB11) <-> K230, USART2 (PA2/PA3) -> XCOM log
 * Key '1' -> start recognize (0x17)
 * Key '2' -> start enroll    (0x16)
 * Key '3' -> delete "user1"  (0x18)
 *------------------------------------------------------*/
#include "stm32f4xx.h"
#include "delay.h"
#include "beep.h"
#include "keypad.h"
#include "usart.h"
#include "uart_protocol.h"
#include <stdio.h>

static void Print_RxFrame(void)
{
    uint8_t i;

    switch (rx_cmd) {
    case 0x25: printf("[ENROLL RESULT]  "); break;
    case 0x26: printf("[RECOG  RESULT]  "); break;
    case 0x27: printf("[DELETE RESULT]  "); break;
    default:   printf("[UNKNOWN 0x%02X] ", rx_cmd); break;
    }

    printf("LEN=%d DATA=", rx_data_len);
    for (i = 0; i < rx_data_len; i++)
        printf("%02X ", rx_data[i]);

    /* printable ASCII tail (name/score readable) */
    if (rx_data_len) {
        printf(" | ");
        for (i = 0; i < rx_data_len; i++)
            printf("%c", (rx_data[i] >= 0x20 && rx_data[i] < 0x7F) ? rx_data[i] : '.');
    }
    printf("\r\n");
}

int main(void)
{
    char key;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    BEEP_Init();
    KEYPAD_Init();
    USART2_Init();
    UART_Protocol_Init();

    printf("=== K230 Integration ===\r\n");
    printf("1=recog 2=enroll 3=delete user1\r\n");

    while (1)
    {
        key = KEYPAD_GetChar();
        if (key == '1') { printf("TX: start recog\r\n");  Send_Recog();  BEEP_Beep(30); }
        if (key == '2') { printf("TX: start enroll\r\n"); Send_Enroll(); BEEP_Beep(30); }
        if (key == '3') { printf("TX: delete user1\r\n"); Send_Delete("user1"); BEEP_Beep(30); }

        if (Get_Rx_Flag()) {
            Print_RxFrame();
            BEEP_Beep(50);
            Clear_Rx_Flag();
        }
        delay_ms(15);
    }
}
