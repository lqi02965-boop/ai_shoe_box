/*------------------------------------------------------
 * beep.c - ���������� (PA5 = TIM2_CH1 PWM)
 * ϴЬ������Ь��ϵͳ
 *------------------------------------------------------*/
#include "beep.h"
#include "delay.h"


void BEEP_Init(void)
{
   
   
    

    /* ʱ�� */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    /* PA5 ���� TIM2_CH1 */
		GPIO_InitTypeDef       gpio;
	
    gpio.GPIO_Mode  = GPIO_Mode_AF;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Pin   = GPIO_Pin_5;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource5, GPIO_AF_TIM2);

    /* TIM2 ��������: 100kHz / (49+1) = 2kHz */
		
		 TIM_TimeBaseInitTypeDef tim;
    tim.TIM_ClockDivision = TIM_CKD_DIV1;
    tim.TIM_CounterMode   = TIM_CounterMode_Up;
    tim.TIM_Period        = BEEP_ARR;
    tim.TIM_Prescaler     = 839;
    TIM_TimeBaseInit(TIM2, &tim);

    /* TIM2 CH1 PWM */
		TIM_OCInitTypeDef       oc;
    oc.TIM_OCMode      = TIM_OCMode_PWM1;
    oc.TIM_OCPolarity  = TIM_OCPolarity_High;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    oc.TIM_Pulse       = 0;          /* ��ʼ CCR=0, ���� */
    TIM_OC1Init(TIM2, &oc);

    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}

void BEEP_On(void)
{
    TIM_SetCompare1(TIM2, BEEP_CCR);   /* 50%ռ�ձ�, �� */
}

void BEEP_Off(void)
{
     TIM_SetCompare1(TIM2, BEEP_ARR + 1);  /* CCR=50 > ARR=49, CNT��Զ<CCR, ȫ�ߵ�ƽ, ���� */
}

void BEEP_Beep(uint32_t ms)
{
    BEEP_On();
    delay_ms(ms);
    BEEP_Off();
}
