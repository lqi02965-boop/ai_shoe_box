#ifndef __OLED_H
#define __OLED_H

#include "stm32f4xx.h"

/* ========== OLED SH1106 1.3�� 128x64 ========== */
/* ���� I2C: PB8=SCL, PB9=SDA (���İ�H10�ӿ�), ��ַ 0x78 */
#define OLED_SCL_PORT     GPIOB
#define OLED_SDA_PORT     GPIOB
#define OLED_SCL_PIN      GPIO_Pin_8
#define OLED_SDA_PIN      GPIO_Pin_9
#define OLED_RCC_GPIO     RCC_AHB1Periph_GPIOB
#define OLED_I2C_ADDR     0x78

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ClearLine(uint8_t row);
void OLED_SetCursor(uint8_t row, uint8_t col);
void OLED_PrintChar(char c);
void OLED_PrintString(const char *str);
void OLED_ShowNum(uint8_t row, uint8_t col, uint32_t num, uint8_t len);
void OLED_Refresh(void);

#endif /* __OLED_H */
