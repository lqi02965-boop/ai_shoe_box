/*------------------------------------------------------
 * rgb_led.c - RGB LED (������, �͵�ƽ��)
 * PE13=R, PE12=G, PE11=B
 *------------------------------------------------------*/
#include "rgb_led.h"

static LED_Color current_color = LED_OFF;
static uint8_t blink_counter = 0;
static uint8_t blink_toggle  = 0;

/* ������: 1=��(����), 0=��(����) */
static void RGB_Apply(uint8_t r, uint8_t g, uint8_t b)
{
    if (r) GPIO_ResetBits(RGB_GPIO, RGB_R_PIN);
    else   GPIO_SetBits  (RGB_GPIO, RGB_R_PIN);

    if (g) GPIO_ResetBits(RGB_GPIO, RGB_G_PIN);
    else   GPIO_SetBits  (RGB_GPIO, RGB_G_PIN);

    if (b) GPIO_ResetBits(RGB_GPIO, RGB_B_PIN);
    else   GPIO_SetBits  (RGB_GPIO, RGB_B_PIN);
}

void RGB_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_AHB1PeriphClockCmd(RGB_RCC_GPIO, ENABLE);

    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_Pin   = RGB_R_PIN | RGB_G_PIN | RGB_B_PIN;
    GPIO_Init(RGB_GPIO, &gpio);

    /* ��ʼȫ��: ������, �ߵ�ƽ�� */
    GPIO_SetBits(RGB_GPIO, RGB_R_PIN | RGB_G_PIN | RGB_B_PIN);
}

void RGB_SetColor(LED_Color color)
{
    current_color = color;

    switch (color) {
        case LED_GREEN:  RGB_Apply(0, 1, 0); break;
        case LED_RED:    RGB_Apply(1, 0, 0); break;
        case LED_YELLOW: RGB_Apply(1, 1, 0); break;
        case LED_BLUE:   RGB_Apply(0, 0, 1); break;
        case LED_OFF:    RGB_Apply(0, 0, 0); break;
        default:         RGB_Apply(0, 0, 0); break;
    }
}

/* ÿ 100ms ����һ��, �Ƶ� 500ms ��˸ */
void RGB_Tick(void)
{
    blink_counter++;
    if (blink_counter >= 5) {
        blink_counter = 0;
        blink_toggle = !blink_toggle;
    }

    if (current_color == LED_YELLOW) {
        if (blink_toggle) RGB_Apply(1, 1, 0);
        else              RGB_Apply(0, 0, 0);
    }
}
