#include "uart_protocol.h"
#include <string.h>

/* ============ ȫ�ֱ��� ============ */
uint8_t  rx_cmd        = 0;
uint8_t  rx_data[RX_BUF_SIZE] = {0};
uint8_t  rx_data_len   = 0;
uint8_t  rx_flag        = 0;   /* �յ�����֡��־ */

/* ����״̬������ */
static uint8_t  rx_state   = RX_WAIT_HEAD;
static uint8_t  rx_buf[RX_BUF_SIZE];
static uint8_t  rx_index   = 0;
static uint8_t  rx_len     = 0;
static uint8_t  rx_crc     = 0;

/* ============ CRC8 ���㣨����ʽ 0x07���� K230 һ�£� ============ */
static uint8_t Calc_CRC8(uint8_t *data, uint8_t len)
{
    uint8_t crc = 0;
    uint8_t i, j;
    for (i = 0; i < len; i++) {
        crc ^= data[i];
        for (j = 0; j < 8; j++) {
            if (crc & 0x80)
                crc = (crc << 1) ^ 0x07;
            else
                crc <<= 1;
        }
    }
    return crc;
}

/* ============ USART3 ��ʼ����PB10-TX, PB11-RX, 115200, 8N1�� ============ */
void UART_Protocol_Init(void)
{
    GPIO_InitTypeDef   GPIO_InitStruct;
    USART_InitTypeDef  USART_InitStruct;
    NVIC_InitTypeDef   NVIC_InitStruct;

    /* ��ʱ�� */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    /* PB10-TX �������� */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* PB11-RX �������� */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_11;
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USART3 ���� */
    USART_InitStruct.USART_BaudRate            = 115200;
    USART_InitStruct.USART_WordLength          = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits            = USART_StopBits_1;
    USART_InitStruct.USART_Parity              = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART3, &USART_InitStruct);

    /* ���������ж� */
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

    /* NVIC ���� */
    NVIC_InitStruct.NVIC_IRQChannel                   = USART3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority        = 2;
    NVIC_InitStruct.NVIC_IRQChannelCmd               = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    USART_Cmd(USART3, ENABLE);
}

/* ============ ��֡������ ============ */
void Send_Frame(uint8_t cmd, uint8_t *data, uint8_t len)
{
    uint8_t buf[40];
    uint8_t i;
    uint8_t crc;

    /* ��֡��[HEAD][LEN][CMD][DATA...][CRC][TAIL] */
    buf[0] = FRAME_HEAD;
    buf[1] = len + 1;           /* LEN = �����򳤶� + 1�������ֽڣ� */
    buf[2] = cmd;
    for (i = 0; i < len; i++) {
        buf[3 + i] = data[i];
    }
    crc = Calc_CRC8(&buf[1], 2 + len);   /* ���㷶Χ��LEN+CMD+DATA */
    buf[3 + len] = crc;
    buf[4 + len] = FRAME_TAIL;

    /* ---------- ���� ---------- */
    for (i = 0; i < 5 + len; i++) {
        while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
        USART_SendData(USART3, buf[i]);
    }
    while (USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);

    /* ====== ���Դ�ӡ��ͨ�� USART2 ����� XCOM�� ====== */
    printf("TX: ");
    for (i = 0; i < 5 + len; i++) {
        printf("%02X ", buf[i]);
    }
    printf("\r\n");
}

/* ============ ��װ�������� ============ */
void Send_Enroll(void)
{
    Send_Frame(CMD_START_ENROLL, 0, 0);
}

void Send_Recog(void)
{
    Send_Frame(CMD_START_RECOG, 0, 0);
}

void Send_Delete(char *name)
{
    uint8_t data[32];
    uint8_t name_len = strlen(name);
    if (name_len > 31) name_len = 31;
    data[0] = name_len;
    memcpy(&data[1], name, name_len);
    Send_Frame(CMD_DELETE_FACE, data, 1 + name_len);
}

/* ============ ��ȡ/������ձ�־ ============ */
uint8_t Get_Rx_Flag(void)  { return rx_flag; }
void    Clear_Rx_Flag(void) { rx_flag = 0; }

/* ============ USART3 �жϷ�����������״̬���� ============ */
void USART3_IRQHandler(void)
{
    uint8_t byte;
		if (USART_GetFlagStatus(USART3, USART_FLAG_ORE) != RESET) {
        USART_ReceiveData(USART3);             /* ��DR��ORE, ���жϿ��� */
    }

    if (USART_GetITStatus(USART3, USART_IT_RXNE) != RESET) {
        byte = USART_ReceiveData(USART3);

        switch (rx_state) {

        case RX_WAIT_HEAD:       /* ��֡ͷ 0xAA */
            if (byte == FRAME_HEAD) {
                rx_buf[0]  = byte;
                rx_index   = 1;
                rx_state   = RX_WAIT_LEN;
            }
            break;

        case RX_WAIT_LEN:         /* ������: LEN = 1(CMD) + N(DATA) */
            if (byte == 0 || byte > 33) {      /* �Ƿ�����, ������֡ͷ */
                rx_state = RX_WAIT_HEAD;
                break;
            }
            rx_buf[1]  = byte;
            rx_len     = byte - 1;             /* תΪ�����ݳ��� N */
            rx_index   = 2;
            rx_state   = RX_WAIT_CMD;
            break;


        case RX_WAIT_CMD:         /* �������� */
            rx_buf[2]  = byte;
            rx_index   = 3;
            if (rx_len > 0) {
                rx_state = RX_WAIT_DATA;
            } else {
                rx_state = RX_WAIT_CRC;
            }
            break;

        case RX_WAIT_DATA:        /* �������� */
            rx_buf[rx_index] = byte;
            rx_index++;
            if (rx_index >= 3 + rx_len) {
                rx_state = RX_WAIT_CRC;
            }
            break;

        case RX_WAIT_CRC:         /* У�� CRC */
            {
                uint8_t crc_calc = Calc_CRC8(&rx_buf[1], 2 + rx_len);
                if (byte == crc_calc) {
                    rx_buf[rx_index] = byte;
                    rx_index++;
                    rx_state = RX_WAIT_TAIL;
                } else {
                    /* CRC ����������֡ͷ */
                    rx_state = RX_WAIT_HEAD;
                }
            }
            break;

        case RX_WAIT_TAIL:        /* ��֡β 0x55 */
            if (byte == FRAME_TAIL) {
                /* ����֡�յ�����ȡ CMD �� DATA */
                rx_cmd      = rx_buf[2];
                rx_data_len = rx_len;
                memcpy(rx_data, &rx_buf[3], rx_len);
                rx_flag     = 1;  /* ֪ͨ��ѭ������ */
            }
            /* ���۳ɹ�ʧ�ܣ��ص���֡ͷ */
            rx_state = RX_WAIT_HEAD;
            break;
        }

        USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }
}
