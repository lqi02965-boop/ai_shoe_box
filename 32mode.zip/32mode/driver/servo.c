/*------------------------------------------------------
 * servo.c - SG90 180�ȶ��
 * PE6 = TIM9_CH2, AF3
 *
 * TIM9 �� APB2, ��ʱ��ʱ�� 168MHz
 * PSC = 1680-1 -> 100kHz (10us/count)
 * ARR = 2000-1 -> 20ms = 50Hz
 * CCR = 50 + angle * 200 / 180
 *   0�� = 50   (1.0ms)
 *   90�� = 150 (3.0ms)
 *   180�� = 250 (5.0ms... ʵ��SG90Լ2.5ms����)
 *------------------------------------------------------*/
#include "servo.h"
static uint8_t servo_opened = 0;   /* 0=��, 1=�� */
void SERVO_Init(void)
{
    GPIO_InitTypeDef        gpio;
    TIM_TimeBaseInitTypeDef tim;
    TIM_OCInitTypeDef       oc;

    /* ��ʱ�� */
    RCC_APB2PeriphClockCmd(SERVO_RCC_TIM, ENABLE);
    RCC_AHB1PeriphClockCmd(SERVO_RCC_GPIO, ENABLE);

    /* PE6 ���� TIM9_CH2 */
    GPIO_PinAFConfig(SERVO_GPIO, GPIO_PinSource6, SERVO_AF);

    gpio.GPIO_Mode  = GPIO_Mode_AF;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_Pin   = SERVO_PIN;
    GPIO_Init(SERVO_GPIO, &gpio);

    /* TIM9 ʱ��: 100kHz, 20ms���� = 50Hz */
    tim.TIM_ClockDivision     = TIM_CKD_DIV1;
    tim.TIM_CounterMode       = TIM_CounterMode_Up;
    tim.TIM_Prescaler         = 1680 - 1;
    tim.TIM_Period            = 2000 - 1;
    tim.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(SERVO_TIM, &tim);

    /* TIM9_CH2 PWM, �ֶ���ȫ���ֶ� */
    oc.TIM_OCMode      = TIM_OCMode_PWM1;
    oc.TIM_OutputState  = TIM_OutputState_Enable;
    oc.TIM_OutputNState = TIM_OutputNState_Disable;
    oc.TIM_Pulse        = 50;           /* Ĭ��0�� */
    oc.TIM_OCPolarity  = TIM_OCPolarity_High;
    oc.TIM_OCNPolarity = TIM_OCNPolarity_High;
    oc.TIM_OCIdleState = TIM_OCIdleState_Reset;
    oc.TIM_OCNIdleState= TIM_OCNIdleState_Reset;

    TIM_OC2Init(SERVO_TIM, &oc);
    TIM_OC2PreloadConfig(SERVO_TIM, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(SERVO_TIM, ENABLE);
    TIM_Cmd(SERVO_TIM, ENABLE);

    /* TIM9 �� APB2 ��, ����ʹ������� */
    TIM_CtrlPWMOutputs(SERVO_TIM, ENABLE);
	
    servo_opened = 0;   /* �ϵ�Ĭ�Ϲ��� */

		
}

void SERVO_SetAngle(uint8_t angle)
{
    if (angle > 180) angle = 180;
    uint16_t ccr = 50 + (uint16_t)angle * 200 / 180;
    TIM_SetCompare2(SERVO_TIM, ccr);
}

void SERVO_Open(void)
{
    SERVO_SetAngle(90);
}

void SERVO_Close(void)
{
    SERVO_SetAngle(0);
}
/*----------  toggle  ----------*/


void SERVO_Toggle(void)
{
    if (servo_opened) {
        SERVO_Close();
        servo_opened = 0;
    } else {
        SERVO_Open();
        servo_opened = 1;
    }
}
