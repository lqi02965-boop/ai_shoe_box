#ifndef __KEYPAD_H
#define __KEYPAD_H
#include "stm32f4xx.h"

/*
 * 4x4 Matrix Keypad - Shoe Wash Project (probed 2026-08-21)
 * Rows (output, scan low) : PC11, PB6, PE5, PC7
 * Cols (input, pull-up)   : PA8, PC6, PC8, PC9
 *
 * Probed layout (each key = row x col):
 *           PC6	   PC7	    PC8	  PC9
 *   PC11      1      2      3      A
 *   PB6       4      5      6      B
 *   PE5       7      8      9      C
 *  PA8      *      0      #      D
 *
 * '*' = cancel/back    '#' = confirm/enter
 */

#define KEY_ROW1_PORT   GPIOC
#define KEY_ROW1_PIN    GPIO_Pin_11
#define KEY_ROW2_PORT   GPIOB
#define KEY_ROW2_PIN    GPIO_Pin_6
#define KEY_ROW3_PORT   GPIOE
#define KEY_ROW3_PIN    GPIO_Pin_5
#define KEY_ROW4_PORT   GPIOA          /* was GPIOC */
#define KEY_ROW4_PIN    GPIO_Pin_8     /* was GPIO_Pin_7 */

#define KEY_COL1_PORT   GPIOC          /* was GPIOA */
#define KEY_COL1_PIN    GPIO_Pin_6     /* was GPIO_Pin_8 */

#define KEY_COL2_PORT   GPIOC
#define KEY_COL2_PIN    GPIO_Pin_7     /* was GPIO_Pin_6 */

#define KEY_COL3_PORT   GPIOC
#define KEY_COL3_PIN    GPIO_Pin_8
#define KEY_COL4_PORT   GPIOC
#define KEY_COL4_PIN    GPIO_Pin_9

#define KEYPAD_ROWS     4
#define KEYPAD_COLS     4

/* KEYPAD_GetChar() return when no key */
#define KEY_NONE_CHAR   0x00

void    KEYPAD_Init(void);
uint8_t KEYPAD_Scan(void);      /* 0-15 (row*4+col), 0xFF = none */
char    KEYPAD_GetChar(void);   /* '0'-'9','*','#','A'-'D' or 0x00 */

#endif
