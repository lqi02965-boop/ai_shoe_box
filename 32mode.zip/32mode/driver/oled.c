/*------------------------------------------------------
 * oled.c - SH1106 1.3�� 128x64
 * ���� I2C: SCL=PB8, SDA=PB9 (���İ�H10�ӿ�)
 * ��ַ: 0x78, �е�ַƫ��+2
 *------------------------------------------------------*/
#include "oled.h"
#include "oled_font.h"
#include "delay.h"

static uint8_t OLED_Buffer[8][128];
static uint8_t cursor_row = 0;
static uint8_t cursor_col = 0;

#define SCL_HIGH()  GPIO_SetBits(OLED_SCL_PORT, OLED_SCL_PIN)
#define SCL_LOW()   GPIO_ResetBits(OLED_SCL_PORT, OLED_SCL_PIN)
#define SDA_HIGH()  GPIO_SetBits(OLED_SDA_PORT, OLED_SDA_PIN)
#define SDA_LOW()   GPIO_ResetBits(OLED_SDA_PORT, OLED_SDA_PIN)

static void I2C_Delay(void) { delay_us(5); }

static void I2C_Start(void)
{
    SDA_HIGH(); SCL_HIGH(); I2C_Delay();
    SDA_LOW(); I2C_Delay();
    SCL_LOW();
}

static void I2C_Stop(void)
{
    SDA_LOW(); SCL_HIGH(); I2C_Delay();
    SDA_HIGH(); I2C_Delay();
}

/* ��9��ʱ��: ���ӻ�ACK��, ����Ӧ��λ */
static void I2C_GiveAck(void)
{
    SDA_HIGH(); I2C_Delay();   /* �ͷ�SDA */
    SCL_HIGH(); I2C_Delay();   /* ��9��ʱ�� */
    SCL_LOW(); I2C_Delay();
}

static void I2C_WriteByte(uint8_t data)
{
    uint8_t i;
    for (i = 0; i < 8; i++) {
        if (data & 0x80) SDA_HIGH(); else SDA_LOW();
        I2C_Delay();
        SCL_HIGH(); I2C_Delay();
        SCL_LOW(); I2C_Delay();
        data <<= 1;
    }
    I2C_GiveAck();   /* ����9��ʱ�� */
}

static void OLED_WriteCmd(uint8_t cmd)
{
    I2C_Start();
    I2C_WriteByte(OLED_I2C_ADDR);
    I2C_WriteByte(0x00);
    I2C_WriteByte(cmd);
    I2C_Stop();
}

static void OLED_WriteData(uint8_t data)
{
    I2C_Start();
    I2C_WriteByte(OLED_I2C_ADDR);
    I2C_WriteByte(0x40);
    I2C_WriteByte(data);
    I2C_Stop();
}

static void OLED_GPIO_Init(void)
{
    GPIO_InitTypeDef mygpio;
    RCC_AHB1PeriphClockCmd(OLED_RCC_GPIO, ENABLE);

    mygpio.GPIO_Mode  = GPIO_Mode_OUT;
    mygpio.GPIO_OType = GPIO_OType_PP;
    mygpio.GPIO_PuPd  = GPIO_PuPd_UP;
    mygpio.GPIO_Speed = GPIO_High_Speed;
    mygpio.GPIO_Pin   = OLED_SCL_PIN | OLED_SDA_PIN;
    GPIO_Init(OLED_SCL_PORT, &mygpio);

    SCL_HIGH();
    SDA_HIGH();
}

void OLED_Init(void)
{
    OLED_GPIO_Init();
    delay_ms(100);

    OLED_WriteCmd(0xAE);  // ����ʾ
    OLED_WriteCmd(0x20);  // ����Ѱַģʽ
    OLED_WriteCmd(0x10);  // ҳģʽ
    OLED_WriteCmd(0xB0);  // ��ʼҳ
    OLED_WriteCmd(0xC8);  // ����ɨ��
    OLED_WriteCmd(0x00);  // �е͵�ַ
    OLED_WriteCmd(0x10);  // �иߵ�ַ
    OLED_WriteCmd(0x40);  // ��ʼ��
    OLED_WriteCmd(0x81);  // �Աȶ�
    OLED_WriteCmd(0xFF);
    OLED_WriteCmd(0xA1);  // ����ӳ��
    OLED_WriteCmd(0xA6);  // ������ʾ
    OLED_WriteCmd(0xA8);  // ��·����
    OLED_WriteCmd(0x3F);
    OLED_WriteCmd(0xA4);  // ���RAM����
    OLED_WriteCmd(0xD3);  // ��ʾƫ��
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xD5);  // ʱ�ӷ�Ƶ
    OLED_WriteCmd(0xF0);
    OLED_WriteCmd(0xD9);  // �������
    OLED_WriteCmd(0x22);
    OLED_WriteCmd(0xDA);  // COMӲ������
    OLED_WriteCmd(0x12);
    OLED_WriteCmd(0xDB);  // VCOMH
    OLED_WriteCmd(0x20);
    OLED_WriteCmd(0x8D);  // ����
    OLED_WriteCmd(0x14);
    OLED_WriteCmd(0xAF);  // ����ʾ

    OLED_Clear();
}

void OLED_Refresh(void)
{
    uint8_t page, j;
    for (page = 0; page < 8; page++) {
        OLED_WriteCmd(0xB0 | page);
        OLED_WriteCmd(0x02);   /* SH1106 ��ƫ��+2 */
        OLED_WriteCmd(0x10);
        for (j = 0; j < 128; j++) {
            OLED_WriteData(OLED_Buffer[page][j]);
        }
    }
}

void OLED_Clear(void)
{
    uint8_t i, j;
    for (i = 0; i < 8; i++)
        for (j = 0; j < 128; j++)
            OLED_Buffer[i][j] = 0x00;
    OLED_Refresh();
    cursor_row = 0;
    cursor_col = 0;
}

void OLED_ClearLine(uint8_t row)
{
    uint8_t j;
    uint8_t p0 = row * 2;
    uint8_t p1 = p0 + 1;
    for (j = 0; j < 128; j++) {
        OLED_Buffer[p0][j] = 0;
        OLED_Buffer[p1][j] = 0;
    }
    OLED_WriteCmd(0xB0 | p0);
    OLED_WriteCmd(0x02);   /* SH1106 ��ƫ��+2 */
    OLED_WriteCmd(0x10);
    for (j = 0; j < 128; j++) OLED_WriteData(0);
    OLED_WriteCmd(0xB0 | p1);
    OLED_WriteCmd(0x02);   /* SH1106 ��ƫ��+2 */
    OLED_WriteCmd(0x10);
    for (j = 0; j < 128; j++) OLED_WriteData(0);
}

void OLED_SetCursor(uint8_t row, uint8_t col)
{
    cursor_row = row;
    cursor_col = col;
}

void OLED_PrintChar(char c)
{
    uint8_t i, j, page0, page1;
    if (c < 0x20 || c > 0x7E) c = 0x20;
    c -= 0x20;

    page0 = cursor_row * 2;
    page1 = page0 + 1;

    for (i = 0; i < 8; i++) {
        j = cursor_col * 8 + i;
        if (j < 128) {
            OLED_Buffer[page0][j] = OLED_F8x16[c][i];
            OLED_Buffer[page1][j] = OLED_F8x16[c][i + 8];
        }
    }

    cursor_col++;
    if (cursor_col >= 16) {
        cursor_col = 0;
        if (cursor_row < 3) cursor_row++;
    }
}

void OLED_PrintString(const char *str)
{
    while (*str) OLED_PrintChar(*str++);
}

void OLED_ShowNum(uint8_t row, uint8_t col, uint32_t num, uint8_t len)
{
    OLED_SetCursor(row, col);
    char buf[12];
    int32_t i = 0;
    if (num == 0 && len > 0) {
        buf[i++] = '0';
    } else {
        char tmp[12];
        int32_t n = 0;
        while (num > 0 && n < 11) {
            tmp[n++] = '0' + (num % 10);
            num /= 10;
        }
        while (n < len) tmp[n++] = '0';
        while (n > 0) buf[i++] = tmp[--n];
    }
    buf[i] = '\0';
    OLED_PrintString(buf);
}
