/*------------------------------------------------------
 * USART2 driver - PC link
 * PA2 TX / PA3 RX, 115200 8N1, RX interrupt
 * printf redirected to USART2 (needs MicroLIB)
 *------------------------------------------------------*/
#include "usart.h"

static volatile uint8_t u2_data = 0;
static volatile uint8_t u2_flag = 0;

void USART2_Init(void)
{
    GPIO_InitTypeDef  gpio;
    USART_InitTypeDef usart;
    NVIC_InitTypeDef  nvic;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

    /* PA2 TX */
    gpio.GPIO_Pin   = GPIO_Pin_2;
    gpio.GPIO_Mode  = GPIO_Mode_AF;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_PuPd  = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &gpio);

    /* PA3 RX */
    gpio.GPIO_Pin = GPIO_Pin_3;
    GPIO_Init(GPIOA, &gpio);

    usart.USART_BaudRate            = 115200;
    usart.USART_WordLength          = USART_WordLength_8b;
    usart.USART_StopBits            = USART_StopBits_1;
    usart.USART_Parity              = USART_Parity_No;
    usart.USART_Mode                = USART_Mode_Rx | USART_Mode_Tx;
    usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART2, &usart);

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    nvic.NVIC_IRQChannel = USART2_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1;
    nvic.NVIC_IRQChannelSubPriority = 1;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);

    USART_Cmd(USART2, ENABLE);
}

void USART2_SendByte(uint8_t b)
{
    USART_SendData(USART2, b);
    while (USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}

void USART2_SendString(const char *s)
{
    while (*s)
        USART2_SendByte((uint8_t)*s++);
}

uint8_t USART2_Read(void)
{
    if (u2_flag) {
        u2_flag = 0;
        return u2_data;
    }
    return 0;
}

int fputc(int ch, FILE *f)
{
    USART2_SendByte((uint8_t)ch);
    return ch;
}

void USART2_IRQHandler(void)
{
    uint8_t d;

    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        d = USART_ReceiveData(USART2) & 0xFF;
        if (d != '\r' && d != '\n') {   /* XCOM newline filter */
            u2_data = d;
            u2_flag = 1;
        }
    }
}
