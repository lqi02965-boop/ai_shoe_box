#ifndef __USART_H
#define __USART_H
#include "stm32f4xx.h"
#include <stdio.h>

/*
 * USART2 - PC debug / host link
 * PA2 = TX (AF7), PA3 = RX (AF7), 115200 8N1
 * USB-TTL wiring: TTL_RX->PA2, TTL_TX->PA3, GND->GND
 */

void    USART2_Init(void);
void    USART2_SendByte(uint8_t b);
void    USART2_SendString(const char *s);
uint8_t USART2_Read(void);      /* last RX byte, 0 if none */

#endif
