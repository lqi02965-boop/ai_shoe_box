/*------------------------------------------------------
 * 4x4 Matrix Keypad Driver (probed wiring)
 * Rows: PC11, PB6, PE5, PA8 (output, active-low scan)
 * Cols: PC6, PC7, PC8, PC9  (input, pull-up)
 *
 * Scan: pull one row low, read columns.
 * Debounce: 3-state machine, 15ms call period.
 *------------------------------------------------------*/
#include "keypad.h"

static GPIO_TypeDef* row_port[KEYPAD_ROWS] = {
    KEY_ROW1_PORT, KEY_ROW2_PORT, KEY_ROW3_PORT, KEY_ROW4_PORT
};
static const uint16_t row_pin[KEYPAD_ROWS] = {
    KEY_ROW1_PIN, KEY_ROW2_PIN, KEY_ROW3_PIN, KEY_ROW4_PIN
};

static GPIO_TypeDef* col_port[KEYPAD_COLS] = {
    KEY_COL1_PORT, KEY_COL2_PORT, KEY_COL3_PORT, KEY_COL4_PORT
};
static const uint16_t col_pin[KEYPAD_COLS] = {
    KEY_COL1_PIN, KEY_COL2_PIN, KEY_COL3_PIN, KEY_COL4_PIN
};

/* key map: [row][col] -> ASCII (probed 2026-08-21) */
static const char key_map[KEYPAD_ROWS][KEYPAD_COLS] = {
    {'1', '2', '3', 'A'},
    {'4', '5', '6', 'B'},
    {'7', '8', '9', 'C'},
    {'*', '0', '#', 'D'},
};


typedef enum {
    KEY_STATE_WAIT_PRESS = 0,
    KEY_STATE_DEBOUNCE,
    KEY_STATE_WAIT_RELEASE
} KeyState_t;

static KeyState_t key_state = KEY_STATE_WAIT_PRESS;
static uint8_t  last_key_code    = 0xFF;
static uint8_t  debounce_counter = 0;

static void KEYPAD_RowsAllHigh(void)
{
    uint8_t i;
    for (i = 0; i < KEYPAD_ROWS; i++)
        GPIO_SetBits(row_port[i], row_pin[i]);
}

void KEYPAD_Init(void)
{
    GPIO_InitTypeDef gpio;
    uint8_t i;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB |
                           RCC_AHB1Periph_GPIOC | RCC_AHB1Periph_GPIOE, ENABLE);

    /* rows: push-pull output, default high */
    gpio.GPIO_Pin   = 0;
    gpio.GPIO_Mode  = GPIO_Mode_OUT;
    gpio.GPIO_OType = GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    gpio.GPIO_PuPd  = GPIO_PuPd_NOPULL;

    for (i = 0; i < KEYPAD_ROWS; i++) {
        gpio.GPIO_Pin = row_pin[i];
        GPIO_Init(row_port[i], &gpio);
        GPIO_SetBits(row_port[i], row_pin[i]);
    }

    /* cols: input pull-up */
    gpio.GPIO_Mode = GPIO_Mode_IN;
    gpio.GPIO_PuPd = GPIO_PuPd_UP;

    for (i = 0; i < KEYPAD_COLS; i++) {
        gpio.GPIO_Pin = col_pin[i];
        GPIO_Init(col_port[i], &gpio);
    }
}

/* raw scan, returns 0-15 or 0xFF */
uint8_t KEYPAD_Scan(void)
{
    uint8_t row, col;
    volatile uint32_t t;

    for (row = 0; row < KEYPAD_ROWS; row++) {
        KEYPAD_RowsAllHigh();
        GPIO_ResetBits(row_port[row], row_pin[row]);

        for (t = 0; t < 50; t++);          /* settle ~2us */

        for (col = 0; col < KEYPAD_COLS; col++) {
            if (GPIO_ReadInputDataBit(col_port[col], col_pin[col]) == 0) {
                KEYPAD_RowsAllHigh();
                return row * KEYPAD_COLS + col;
            }
        }
    }
    KEYPAD_RowsAllHigh();
    return 0xFF;
}

/*
 * Debounced read, call every 10-20ms.
 * Fires once per press-release cycle.
 */
char KEYPAD_GetChar(void)
{
    uint8_t code;

    switch (key_state) {
    case KEY_STATE_WAIT_PRESS:
        code = KEYPAD_Scan();
        if (code != 0xFF) {
            last_key_code    = code;
            debounce_counter = 0;
            key_state        = KEY_STATE_DEBOUNCE;
        }
        break;

    case KEY_STATE_DEBOUNCE:
        debounce_counter++;
        if (debounce_counter >= 2) {          /* 2 x 15ms = 30ms stable */
            code = KEYPAD_Scan();
            if (code == last_key_code) {
                key_state = KEY_STATE_WAIT_RELEASE;
                return key_map[code / KEYPAD_COLS][code % KEYPAD_COLS];
            }
            key_state = KEY_STATE_WAIT_PRESS; /* jitter, abort */
        }
        break;

    case KEY_STATE_WAIT_RELEASE:
        code = KEYPAD_Scan();
        if (code == 0xFF)
            key_state = KEY_STATE_WAIT_PRESS;
        break;

    default:
        key_state = KEY_STATE_WAIT_PRESS;
        break;
    }
    return KEY_NONE_CHAR;
}
