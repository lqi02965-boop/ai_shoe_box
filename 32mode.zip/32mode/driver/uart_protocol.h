#ifndef __UART_PROTOCOL_H
#define __UART_PROTOCOL_H

#include "stm32f4xx.h"

/* ֡���� */
#define FRAME_HEAD      0xAA
#define FRAME_TAIL      0x55

/* STM32 -> K230 ���� */
#define CMD_START_ENROLL    0x16
#define CMD_START_RECOG      0x17
#define CMD_DELETE_FACE      0x18

/* K230 -> STM32 ���� */
#define CMD_ENROLL_RESULT   0x25
#define CMD_RECOG_RESULT    0x26
#define CMD_DELETE_RESULT   0x27

/* ����״̬�� */
#define RX_WAIT_HEAD    0
#define RX_WAIT_LEN     1
#define RX_WAIT_CMD     2
#define RX_WAIT_DATA    3
#define RX_WAIT_CRC     4
#define RX_WAIT_TAIL    5

#define RX_BUF_SIZE     40

/* �������� */
void UART_Protocol_Init(void);
void Send_Frame(uint8_t cmd, uint8_t *data, uint8_t len);
void Send_Enroll(void);
void Send_Recog(void);
void Send_Delete(char *name);
uint8_t Get_Rx_Flag(void);
void Clear_Rx_Flag(void);
extern uint8_t rx_cmd;
extern uint8_t rx_data[];
extern uint8_t rx_data_len;

#endif
