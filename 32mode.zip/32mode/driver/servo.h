#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f4xx.h"

/* ========== ��� SG90 180�� (PE6 = TIM9_CH2, AF3) ========== */
#define SERVO_GPIO         GPIOE
#define SERVO_RCC_GPIO     RCC_AHB1Periph_GPIOE
#define SERVO_PIN          GPIO_Pin_6
#define SERVO_TIM          TIM9
#define SERVO_RCC_TIM      RCC_APB2Periph_TIM9
#define SERVO_AF           GPIO_AF_TIM9

void SERVO_Init(void);
void SERVO_SetAngle(uint8_t angle);   /* 0~180�� */
void SERVO_Open(void);                /* ����: 90�� */
void SERVO_Close(void);               /* ����: 0�� */
void SERVO_Toggle(void);


#endif /* __SERVO_H */
