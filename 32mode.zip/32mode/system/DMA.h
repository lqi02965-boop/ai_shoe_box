#ifndef __DMA_H
#define __DMA_H
#include "stm32f4xx.h"
void DMA_config(uint32_t data_val,uint32_t memory_add);
void USART_DMA_ENABLE(uint32_t data_val);

#endif
