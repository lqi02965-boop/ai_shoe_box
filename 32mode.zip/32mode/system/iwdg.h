#ifndef __IWDG_H
#define __IWDG_H
#include "stm32f4xx.h"
void IWDG_config(void);


#endif