#ifndef __WWDG_H
#define __WWDG_H
#include "stm32f4xx.h"
void IWDG_config(void);


#endif