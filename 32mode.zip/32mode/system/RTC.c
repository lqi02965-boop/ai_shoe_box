#include "RTC.h"
//RTC��ҪPWR  PWR�����л���Դ 
void RTC_Config(void)
{

	if (RTC_ReadBackupRegister(RTC_BKP_DR0)!=1){
		//ѡ��ʱ�Ӻͷ�Ƶ
				RTC_MODE_CONTROL();
		
		 RTC_Time_rolo();	
		
		RTC_Alarm_Rrgulate();
		
		RTC_WriteBackupRegister(RTC_BKP_DR0,1);
		
		printf("RTC frist start success");
	}else{
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
		//��������Ȩ��
		 PWR_BackupAccessCmd(ENABLE);	
		//�ȴ�ʱ��ͬ��
	 RTC_WaitForSynchro();
		
		EXTI_ClearITPendingBit (EXTI_Line17);
		RTC_ClearFlag (RTC_FLAG_ALRAF) ;
			printf("Dont need to configurelRTC again");
		
		
	}
		RTC_wakeup();

}


//ѡ��ʱ�Ӻͷ�Ƶ
 void RTC_MODE_CONTROL(void){
	 
	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
	 //rcc �ϵ粻��ʧ���� Ҫ�л���Դ Ҳ����Ҫ��pwr ���������pwrʹ��
	 PWR_BackupAccessCmd(ENABLE);
	 
	 uint16_t ASYNCPSC=0;
	 uint16_t SYNCPSC=0;
	 
	 if(LSE_OR_LSI==0){
		 //lse--�����ڲ�
		 //����lseʹ��
		 RCC_LSEConfig(RCC_LSE_ON);
		 //�ȴ�ʱ���ź�У׼���
		 while(RCC_GetFlagStatus(RCC_FLAG_LSERDY)!=SET){}
			 //ΪRTCѡ��ʱ��Դ
		  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
		 
		 ASYNCPSC=127;
		 SYNCPSC=255;
		 
	 }else{
		 //lsi �����ڲ�
		  RCC_LSICmd(ENABLE);
		 //�ȴ�ʱ���ź�У׼���
		 while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY)!=SET){}
			 //ΪRTCѡ��ʱ��Դ
		  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);
			
		 ASYNCPSC=127;
		 SYNCPSC=249;
		 
	 }
	 //����RTCʱ��
	 RCC_RTCCLKCmd(ENABLE);
	 //�ȴ�ʱ��ͬ��
	 RTC_WaitForSynchro();
	 //����RTC
	 RTC_InitTypeDef rrr;
	 rrr.RTC_AsynchPrediv = ASYNCPSC;
    rrr.RTC_HourFormat = RTC_HourFormat_24;
    rrr.RTC_SynchPrediv = SYNCPSC;
	 
	 RTC_Init(&rrr);
	 
 }

void RTC_Time_rolo(void){
	RTC_TimeTypeDef  ttm;
	//����ѡ��12ʱ�� ����Ҫ����
	ttm.RTC_H12=RTC_H12_AM;
	ttm.RTC_Hours=HOUR;
	ttm.RTC_Minutes=MIN;
	ttm.RTC_Seconds=SEC;
	
	RTC_SetTime(RTC_Format_BIN,&ttm);
	
	RTC_DateTypeDef  dada;
	dada.RTC_Date=DATE;
	dada.RTC_Month=MONTH;
	dada.RTC_WeekDay=WEEK;
	dada.RTC_Year=YEAR;
	
	RTC_SetDate(RTC_Format_BIN,&dada);
	
	
}

void RTC_Alarm_Rrgulate(void){
	RTC_AlarmTypeDef myalarm;
	//ƥ�伸����,���ڼ���
	myalarm.RTC_AlarmDateWeekDaySel=RTC_AlarmDateWeekDaySel_WeekDay;
	//���������,������������,�����������ڼ�  ��������������������
	myalarm.RTC_AlarmDateWeekDay=A_WEEK_DAY; 
	
	myalarm.RTC_AlarmMask=RTC_AlarmMask_DateWeekDay;
	
	myalarm.RTC_AlarmTime.RTC_H12=RTC_H12_AM;
	myalarm.RTC_AlarmTime.RTC_Hours=A_HOUR;
	myalarm.RTC_AlarmTime.RTC_Minutes=A_MIN;
	myalarm.RTC_AlarmTime.RTC_Seconds=A_SEC;
	
	RTC_SetAlarm(RTC_Format_BIN, RTC_Alarm_A,&myalarm);
	
	
	//����17���ж���
		EXTI_InitTypeDef aaa;
		aaa.EXTI_Line=EXTI_Line17;
		aaa.EXTI_LineCmd=ENABLE;
		aaa.EXTI_Mode=EXTI_Mode_Interrupt;
		aaa.EXTI_Trigger=EXTI_Trigger_Rising ;
		EXTI_Init(&aaa);


		NVIC_InitTypeDef bbb2;
		bbb2.NVIC_IRQChannel=RTC_Alarm_IRQn ;
		bbb2.NVIC_IRQChannelCmd=ENABLE;
		bbb2.NVIC_IRQChannelPreemptionPriority=1;
		bbb2.NVIC_IRQChannelSubPriority=1;


		 NVIC_Init(&bbb2);
		 
		 RTC_ITConfig(RTC_IT_ALRA,ENABLE);
			RTC_ClearFlag(RTC_FLAG_ALRAF);
			
			RTC_AlarmCmd(RTC_Alarm_A, ENABLE);


}

void RTC_wakeup(void){
	RTC_WakeUpCmd(DISABLE);
	EXTI_ClearITPendingBit (EXTI_Line22);
	//����22���ж���	
	EXTI_InitTypeDef aaa;
		aaa.EXTI_Line=EXTI_Line22;
		aaa.EXTI_LineCmd=ENABLE;
		aaa.EXTI_Mode=EXTI_Mode_Interrupt;
		aaa.EXTI_Trigger=EXTI_Trigger_Rising ;
		EXTI_Init(&aaa);
	
			NVIC_InitTypeDef bbb2;
		bbb2.NVIC_IRQChannel=RTC_WKUP_IRQn;
		bbb2.NVIC_IRQChannelCmd=ENABLE;
		bbb2.NVIC_IRQChannelPreemptionPriority=1;
		bbb2.NVIC_IRQChannelSubPriority=1;


		 NVIC_Init(&bbb2);
	
	  RTC_WakeUpClockConfig(RTC_WakeUpClock_RTCCLK_Div16 );
	
		RTC_SetWakeUpCounter(0x0);
	
		RTC_ClearITPendingBit(RTC_IT_WUT );
		
		RTC_ITConfig(RTC_IT_WUT,ENABLE);
		
		RTC_WakeUpCmd(ENABLE);
	
		
}
//��ʾ������ʱ����
void RTC_SHOWTIME(void){
	
	char showtime[10]={0};
	RTC_TimeTypeDef mytime;
	
	RTC_GetTime(RTC_Format_BIN,&mytime);
	
	sprintf(showtime,"%d:%d:%d",mytime.RTC_Hours,mytime.RTC_Minutes,mytime.RTC_Seconds);
	
	char showdate[10]={0};
	RTC_DateTypeDef mydate;
	
	RTC_GetDate(RTC_Format_BIN,&mydate);
	
	sprintf(showdate,"%d-%d-%d",mydate.RTC_Year,mydate.RTC_Month,mydate.RTC_WeekDay);
	
	printf("Current Time: %s %s \r\n",showdate,showtime);
	
	
}
//����

void RTC_Alarm_IRQHandler(void){
	if(RTC_GetITStatus(RTC_IT_ALRA)==SET){
		
		printf ("alerm is work now...");
		EXTI_ClearITPendingBit (EXTI_Line17);
		RTC_ClearFlag (RTC_FLAG_ALRAF) ;
	}
	
	
	
}


void RTC_WKUP_IRQHandler(void){
	
	if (RTC_GetITStatus (RTC_IT_WUT)== SET){
		
		
		
			RTC_SHOWTIME();
		EXTI_ClearITPendingBit (EXTI_Line22);
		RTC_ClearFlag (RTC_FLAG_WUTF);
	
	
	}
}










