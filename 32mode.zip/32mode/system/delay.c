#include "delay.h"
void delay(volatile uint32_t cnt)
{
	while (cnt >0){
		cnt--;
	}
}


//us  1ms=1000us
//21mhz->1s21 000 000 个数  ->1us数21个数
void delay_us(uint32_t us)
{
	//这里等于0了说明寄存器所有位置0了
	SysTick->CTRL=0;
	//设置重装栽值(所有寄存器的值都快可以设置成二进制,他会自动转换)
	SysTick->LOAD=us*21;
	//清空一下当前技术的寄存器,防止之前计数寄存器中有数
	SysTick->VAL=0;
	//使能(这里传几进制都可以,大部分是16进制
	
	SysTick->CTRL = 0x01;
	while((SysTick->CTRL & 0x00010000)==0);
	SysTick->CTRL=0;
	
	
}


//ms  1ms
void delay_ms(uint32_t ms)
{
		//这里等于0了说明寄存器所有位置0了
	SysTick->CTRL=0;
	//设置重装栽值(所有寄存器的值都快可以设置成二进制,他会自动转换)
	SysTick->LOAD=ms*21*1000;
	//清空一下当前技术的寄存器,防止之前计数寄存器中有数
	SysTick->VAL=0;
	//使能(这里传几进制都可以,大部分是16进制
	SysTick->CTRL=1;
	while((SysTick->CTRL & 0x00010000)==0);
	SysTick->CTRL=0;
	
}



//s  1s
void delay_s(uint32_t s)
{
	
	while(s--){
		delay_ms(500);
		delay_ms(500);
	}
	
}