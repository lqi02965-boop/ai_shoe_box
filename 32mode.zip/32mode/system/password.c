//将按键也放入数组
//在设置一个四位数组(password[n])用来存放密码
/*设置i,  
1=1亮 表示0
2=2亮 表示1
3=3亮 表示回退  可以将n=n--
4=4灭 表示删除  可以将n=0
如果正确则直接开始跑马灯
定义一个bool类型用来显示是否正确
*/
#include "key.h"
#include "led.h"
#include "delay.h"
#include "password.h"
#include <stdbool.h>
void password_control(void){
				uint32_t led_name[4]={GPIO_Pin_14 ,GPIO_Pin_13,GPIO_Pin_6,GPIO_Pin_11};
		uint32_t key_name[4]={GPIO_Pin_2,GPIO_Pin_3 ,GPIO_Pin_4,GPIO_Pin_5};
		uint32_t password[4];
		uint32_t true_password[4]={1,0,0,1};
		uint32_t  i=0;	//这个用来控制灯的亮灭
		uint32_t  b=0; //这个用来控制有几位数字在password中
		bool nome=false ; ///一会这些定义放到main中
	
		//这里应该是如果不对则一直跑
		while(1){
			if(nome==true){
				huose_led();
			}else{
				
					if((GPIO_ReadInputDataBit(GPIOG,key_name[0]))==0){  //(这里一会改成按钮==)
						GPIO_ToggleBits(GPIOG,led_name[0]);
						delay_ms(500);
						GPIO_ToggleBits(GPIOG,led_name[0]);
					
					
						if (b < 4) { // 防止数组越界
                        password[b] = 0;
                        b++;
                    }
					}else if((GPIO_ReadInputDataBit(GPIOG,key_name[1]))==0){
						GPIO_ToggleBits(GPIOG,led_name[1]);
						delay_ms(500);
						GPIO_ToggleBits(GPIOG,led_name[1]);
				
						if (b < 4) { // 防止数组越界
                        password[b] = 1;
                        b++;
                    }
						
					}else if((GPIO_ReadInputDataBit(GPIOG,key_name[2]))==0){
						GPIO_ToggleBits(GPIOG,led_name[2]);
						delay_ms(500);
						GPIO_ToggleBits(GPIOG,led_name[2]);
						if(b>0)b--;
					}else if((GPIO_ReadInputDataBit(GPIOG,key_name[3]))==0){
						GPIO_ToggleBits(GPIOG,led_name[3]);
						delay_ms(500);
						GPIO_ToggleBits(GPIOG,led_name[3]);
						b=0;
					}
					if(b==4){
				//这里还差一个nome=true
						if((password[0]==true_password[0])&&(password[1]==true_password[1])&&(password[2]==true_password[2])&&(password[3]==true_password[3])){
							nome=true;
					}else{
						nome=false;
						b=0;
					}
			}
			
		}
			
		}
		
		
		
		//按钮触发
		//GPIO_ReadInputDataBit(GPIOG,key_name[i])==0
		

	}