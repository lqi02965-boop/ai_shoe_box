#ifndef __RTC_H
#define __RTC_H
#include "stm32f4xx.h"
#include "delay.h"
#include "stdio.h"


#define LSE_OR_LSI 0
#define YEAR 26
#define MONTH 8
#define DATE 6
#define WEEK 4
#define HOUR 9
#define MIN 0
#define SEC 0

#define A_HOUR 9
#define A_MIN 0
#define A_SEC 10
#define A_WEEK_DAY 4

void RTC_Config(void);
void RTC_MODE_CONTROL(void);
void RTC_Time_rolo(void);
void RTC_Alarm_Rrgulate(void);
void RTC_wakeup(void);
void RTC_SHOWTIME(void);
void RTC_Alarm_IRQHandler(void);
void RTC_WKUP_IRQHandler(void);
	
#endif
