#ifndef __PASSWORD_H
#define __PASSWORD_H



#include "stm32f4xx.h"
void password_control(void);


#endif