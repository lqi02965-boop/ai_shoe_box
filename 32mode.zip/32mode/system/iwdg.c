#include "IWDG.h"
void IWDG_config(void){
	//����дʹ�� ����
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	
	IWDG_SetPrescaler(IWDG_Prescaler_64 );
	
	IWDG_SetReload(100);
	
	 IWDG_Enable();
	
	IWDG_ReloadCounter();
	
}