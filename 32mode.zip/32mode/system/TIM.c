#include "TIM.h"

void tim_config(void){
	//基本定时器 6 7
 	 RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	
	TIM_TimeBaseInitTypeDef time;
	//预分频,基本定时器选择不分频
	time.TIM_ClockDivision=TIM_CKD_DIV1;                       
	time.TIM_CounterMode=TIM_CounterMode_Up ;
	//T=(ARR+1)(PSC+1)/84000000
	//0`65535   arr输多少个数(自动重装载寄存器)
	time.TIM_Period=8300;
	//0`65535   psc 分频值   数数快慢
	time.TIM_Prescaler=9999;
	//高级顶显示器才有
	//time.TIM_RepetitionCounter=
	
	
	TIM_TimeBaseInit(TIM6, &time);
	
	
	                 
	
	NVIC_InitTypeDef bbb2={0};
		bbb2.NVIC_IRQChannel= TIM6_DAC_IRQn ;
		bbb2.NVIC_IRQChannelCmd=ENABLE;
		bbb2.NVIC_IRQChannelPreemptionPriority=1;
		bbb2.NVIC_IRQChannelSubPriority=1;
	
		 NVIC_Init(&bbb2);
	
	TIM_ITConfig(TIM6,TIM_IT_Update, ENABLE); 
	TIM_Cmd(TIM6,ENABLE);
	
}


void TIM6_DAC_IRQHandler(void){
	if(	TIM_GetITStatus( TIM6,TIM_IT_Update)){
		GPIO_ToggleBits(GPIOG,GPIO_Pin_14);
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	}
	
}






/*

*/