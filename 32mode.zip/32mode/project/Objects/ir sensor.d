.\objects\ir sensor.o: ..\driver\IR Sensor.c
